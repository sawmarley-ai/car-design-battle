Car Design Battle - MVP (TypeScript frontend)
This ZIP contains a minimal full-stack skeleton with the frontend converted to TypeScript (.tsx).
- Frontend: Vite + React + TypeScript
- Backend: Express + Socket.io (JS)
- Contracts: ERC-721 sample
- Scripts: BOM checker and removal
Configure environment variables before running the backend.


Project prepared by: Mohammed A. Alazzeh
