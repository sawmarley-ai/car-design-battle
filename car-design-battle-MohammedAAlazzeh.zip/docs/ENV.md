# Environment variables (backend)
MONGO_URI=mongodb://localhost:27017/car-design
PORT=4000
JWT_SECRET=verysecret
ETH_PROVIDER_URL=<your_rpc_url_for_testnet>
NFT_STORAGE_KEY=<your_nft_storage_api_key>
